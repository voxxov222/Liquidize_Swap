'use client';

import { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { SwapInterface } from '@/components/SwapInterface';
import { NFAMarketplace } from '@/components/NFAMarketplace';
import { LiquidityPools } from '@/components/LiquidityPools';
import { Stats } from '@/components/Stats';
import { Features } from '@/components/Features';

export default function Home() {
  const [activeTab, setActiveTab] = useState<'swap' | 'nfa' | 'pools'>('swap');

  return (
    <main className="min-h-screen relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '4s' }} />
      </div>

      <Navbar />
      
      <div className="relative z-10">
        <Hero />
        <Stats />
        
        <div className="container mx-auto px-4 py-16">
          <div className="flex justify-center gap-4 mb-8">
            <button
              onClick={() => setActiveTab('swap')}
              className={`px-8 py-3 rounded-lg font-semibold transition-all ${
                activeTab === 'swap'
                  ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white glow'
                  : 'glass text-gray-300 hover:text-white'
              }`}
            >
              Swap
            </button>
            <button
              onClick={() => setActiveTab('nfa')}
              className={`px-8 py-3 rounded-lg font-semibold transition-all ${
                activeTab === 'nfa'
                  ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white glow'
                  : 'glass text-gray-300 hover:text-white'
              }`}
            >
              NFA Marketplace
            </button>
            <button
              onClick={() => setActiveTab('pools')}
              className={`px-8 py-3 rounded-lg font-semibold transition-all ${
                activeTab === 'pools'
                  ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white glow'
                  : 'glass text-gray-300 hover:text-white'
              }`}
            >
              Liquidity Pools
            </button>
          </div>

          {activeTab === 'swap' && <SwapInterface />}
          {activeTab === 'nfa' && <NFAMarketplace />}
          {activeTab === 'pools' && <LiquidityPools />}
        </div>

        <Features />
      </div>
    </main>
  );
}
