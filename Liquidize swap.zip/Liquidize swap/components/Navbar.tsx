'use client';

import { useState } from 'react';
import { Wallet, Menu, X, Droplets } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export function Navbar() {
  const [isConnected, setIsConnected] = useState(false);
  const [address, setAddress] = useState('');
  const [balance, setBalance] = useState('0.00');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const connectWallet = async () => {
    // Mock wallet connection
    const mockAddress = '0x' + Math.random().toString(16).substr(2, 40);
    const mockBalance = (Math.random() * 10).toFixed(2);
    
    setAddress(mockAddress);
    setBalance(mockBalance);
    setIsConnected(true);
    
    toast.success('Wallet Connected', {
      description: `Connected to ${mockAddress.slice(0, 6)}...${mockAddress.slice(-4)}`,
    });
  };

  const disconnectWallet = () => {
    setIsConnected(false);
    setAddress('');
    setBalance('0.00');
    toast.info('Wallet Disconnected');
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-purple-500/20">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <Droplets className="w-10 h-10 text-purple-400" />
              <div className="absolute inset-0 blur-xl bg-purple-500/30" />
            </div>
            <div>
              <h1 className="text-2xl font-bold gradient-text">Liquidize</h1>
              <p className="text-xs text-gray-400">Next-Gen DeFi</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#swap" className="text-gray-300 hover:text-white transition-colors">
              Swap
            </a>
            <a href="#nfa" className="text-gray-300 hover:text-white transition-colors">
              NFA
            </a>
            <a href="#pools" className="text-gray-300 hover:text-white transition-colors">
              Pools
            </a>
            <a href="#earn" className="text-gray-300 hover:text-white transition-colors">
              Earn
            </a>
          </div>

          {/* Wallet Connection */}
          <div className="flex items-center gap-4">
            {isConnected ? (
              <div className="hidden md:flex items-center gap-3">
                <div className="glass px-4 py-2 rounded-lg">
                  <p className="text-sm text-gray-400">Balance</p>
                  <p className="font-semibold text-white">{balance} ETH</p>
                </div>
                <Button
                  onClick={disconnectWallet}
                  className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 glow"
                >
                  <Wallet className="w-4 h-4 mr-2" />
                  {address.slice(0, 6)}...{address.slice(-4)}
                </Button>
              </div>
            ) : (
              <Button
                onClick={connectWallet}
                className="hidden md:flex bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 glow"
              >
                <Wallet className="w-4 h-4 mr-2" />
                Connect Wallet
              </Button>
            )}

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden text-white"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-purple-500/20">
            <div className="flex flex-col gap-4">
              <a href="#swap" className="text-gray-300 hover:text-white transition-colors">
                Swap
              </a>
              <a href="#nfa" className="text-gray-300 hover:text-white transition-colors">
                NFA
              </a>
              <a href="#pools" className="text-gray-300 hover:text-white transition-colors">
                Pools
              </a>
              <a href="#earn" className="text-gray-300 hover:text-white transition-colors">
                Earn
              </a>
              {isConnected ? (
                <>
                  <div className="glass px-4 py-2 rounded-lg">
                    <p className="text-sm text-gray-400">Balance</p>
                    <p className="font-semibold text-white">{balance} ETH</p>
                  </div>
                  <Button
                    onClick={disconnectWallet}
                    className="bg-gradient-to-r from-purple-500 to-blue-500"
                  >
                    Disconnect
                  </Button>
                </>
              ) : (
                <Button
                  onClick={connectWallet}
                  className="bg-gradient-to-r from-purple-500 to-blue-500"
                >
                  <Wallet className="w-4 h-4 mr-2" />
                  Connect Wallet
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
